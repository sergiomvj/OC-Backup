# Resumo Atual do Repositório

## Funcionalidades Necessárias:
- Funcionalidade 1
- Funcionalidade 2

## Alterações Necessárias:
- Ajuste 1
- Ajuste 2