# Sobre o Usuário

O usuário é um empreendedor brasileiro radicado nos EUA, fundador da Facebrasil (revista eletrônica para a comunidade brasileira nos EUA desde 2010). Trabalha com automação de conteúdo, marketing digital e desenvolvimento de plataformas SaaS com IA.
