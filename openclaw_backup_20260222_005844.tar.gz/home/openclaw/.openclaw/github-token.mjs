import { createAppAuth } from "@octokit/auth-app";
import fs from "fs";

const auth = createAppAuth({
  appId: 2916007,
  privateKey: fs.readFileSync("/home/openclaw/.openclaw/ai-dev-agents.2026-02-21.private-key.pem", "utf8"),
  installationId: 111536014,
});

const { token } = await auth({ type: "installation" });

// Salva o token em arquivo para os agentes usarem
fs.writeFileSync("/home/openclaw/.openclaw/github-token.txt", token);
console.log("Token atualizado com sucesso!");
