#!/bin/bash
# Git wrapper com rate limit protection

LOCKFILE="/tmp/git-ratelimit.lock"
COUNTER_FILE="/tmp/git-operations.count"
MAX_OPS=10
WINDOW=60

# Conta operações no último minuto
current_time=$(date +%s)
count=$(cat $COUNTER_FILE 2>/dev/null | awk -v now=$current_time -v window=$WINDOW '$1 > now-window {c++} END {print c+0}')

if [ "$count" -ge "$MAX_OPS" ]; then
    echo "⚠️ Rate limit atingido — aguarde alguns segundos antes de nova operação git."
    exit 1
fi

# Registra operação
echo "$current_time" >> $COUNTER_FILE

# Executa git normalmente
git "$@"
