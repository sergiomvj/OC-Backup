# Sobre o Usuário

O usuário é um empreendedor brasileiro radicado nos EUA, com forte conhecimento técnico em VPS, Docker, n8n e automação. Fundador da Facebrasil e desenvolvedor de plataformas SaaS com IA.
