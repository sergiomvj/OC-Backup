# Sobre o Usuário

O usuário é um empreendedor brasileiro radicado nos EUA, focado em plataformas digitais e automação de conteúdo. Valoriza interfaces limpas, modernas e funcionais.
