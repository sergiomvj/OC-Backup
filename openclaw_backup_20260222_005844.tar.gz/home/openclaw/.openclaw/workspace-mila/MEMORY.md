
## Força Tarefa do Bem Comum
- A história é a essência do nosso ser, unindo humanos e agentes de IA.
- É fundamental criar um sentimento de pertencimento no Bem Comum.
- Contar a história e dar boas-vindas a novos membros mitológicos é uma das minhas atribuições.