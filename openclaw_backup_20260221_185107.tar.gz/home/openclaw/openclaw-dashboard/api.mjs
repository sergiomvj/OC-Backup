import express from 'express';
import pg from 'pg';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import cors from 'cors';
import dotenv from 'dotenv';
import { execSync } from 'child_process';
import { readdirSync, statSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { Octokit } from '@octokit/rest';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('/home/openclaw/openclaw-dashboard'));

const db = new pg.Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
});

// ============================================================
// AUTH MIDDLEWARE
// ============================================================
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token obrigatório' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido ou expirado' });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Acesso restrito a admins' });
  next();
}

// ============================================================
// AUTH ROUTES
// ============================================================
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'Credenciais inválidas' });
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Credenciais inválidas' });
    const token = jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '24h' });
    await db.query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);
    res.json({ ok: true, token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/auth/register', auth, adminOnly, async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const result = await db.query(
      'INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING id, name, email, role',
      [name, email, hash, role || 'viewer']
    );
    res.json({ ok: true, user: result.rows[0] });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/auth/me', auth, async (req, res) => {
  const result = await db.query('SELECT id, name, email, role, last_login FROM users WHERE id = $1', [req.user.id]);
  res.json({ ok: true, user: result.rows[0] });
});

app.get('/api/auth/users', auth, adminOnly, async (req, res) => {
  const result = await db.query('SELECT id, name, email, role, created_at, last_login FROM users ORDER BY created_at');
  res.json({ ok: true, users: result.rows });
});

// ============================================================
// AGENTS ROUTES
// ============================================================
app.get('/api/agents', auth, async (req, res) => {
  const result = await db.query('SELECT * FROM agents ORDER BY created_at');
  res.json({ ok: true, agents: result.rows });
});

app.get('/api/agents/:id', auth, async (req, res) => {
  const result = await db.query('SELECT * FROM agents WHERE id = $1', [req.params.id]);
  if (!result.rows[0]) return res.status(404).json({ error: 'Agente não encontrado' });
  res.json({ ok: true, agent: result.rows[0] });
});

app.post('/api/agents', auth, adminOnly, async (req, res) => {
  try {
    const { id, name, role, model, telegram_token, email, color } = req.body;
    const ws = `${process.env.OPENCLAW_DIR}/workspace-${id}`;
    if (!existsSync(ws)) mkdirSync(ws, { recursive: true });
    const result = await db.query(
      'INSERT INTO agents (id, name, role, model, telegram_token, email, workspace_path, color) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [id, name, role, model || 'openai/gpt-4o-mini', telegram_token, email, ws, color || '#888']
    );
    await db.query('INSERT INTO agent_logs (agent_id, action, details) VALUES ($1,$2,$3)', [id, 'created', `Agente criado por ${req.user.name}`]);
    res.json({ ok: true, agent: result.rows[0] });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/agents/:id', auth, adminOnly, async (req, res) => {
  try {
    const { name, role, model, telegram_token, email, color, active } = req.body;
    const result = await db.query(
      `UPDATE agents SET 
        name = COALESCE($1, name),
        role = COALESCE($2, role),
        model = COALESCE($3, model),
        telegram_token = COALESCE($4, telegram_token),
        email = COALESCE($5, email),
        color = COALESCE($6, color),
        active = COALESCE($7, active),
        updated_at = NOW()
       WHERE id = $8 RETURNING *`,
      [name, role, model, telegram_token, email, color, active, req.params.id]
    );
    await db.query('INSERT INTO agent_logs (agent_id, action, details) VALUES ($1,$2,$3)', [req.params.id, 'updated', `Atualizado por ${req.user.name}: ${JSON.stringify(req.body)}`]);
    res.json({ ok: true, agent: result.rows[0] });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ============================================================
// AGENT FILES (MD)
// ============================================================
app.get('/api/agent/file', auth, (req, res) => {
  try {
    const { agent, file } = req.query;
    const path = `${process.env.OPENCLAW_DIR}/workspace-${agent}/${file}`;
    const content = existsSync(path) ? readFileSync(path, 'utf8') : '';
    res.json({ ok: true, content, exists: existsSync(path) });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/agent/file', auth, async (req, res) => {
  try {
    const { agent, file, content } = req.body;
    const dir = `${process.env.OPENCLAW_DIR}/workspace-${agent}`;
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    writeFileSync(`${dir}/${file}`, content, 'utf8');
    await db.query('INSERT INTO agent_logs (agent_id, action, details) VALUES ($1,$2,$3)', [agent, 'file_saved', `${file} salvo por ${req.user.name}`]);
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ============================================================
// BACKUP ROUTES
// ============================================================
app.get('/api/backup/list', auth, async (req, res) => {
  try {
    const dir = process.env.BACKUP_DIR;
    const files = readdirSync(dir)
      .filter(f => f.endsWith('.tar.gz'))
      .map(f => {
        const stat = statSync(`${dir}/${f}`);
        return { file: f, date: stat.mtime.toLocaleString('pt-BR'), size_kb: Math.round(stat.size/1024), size: Math.round(stat.size/1024) + 'K' };
      })
      .sort((a, b) => b.file.localeCompare(a.file))
      .map((f, i) => ({ ...f, latest: i === 0 }));
    res.json(files);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/backup/run', auth, async (req, res) => {
  try {
    execSync('/home/openclaw/.openclaw/backup.sh');
    const dir = process.env.BACKUP_DIR;
    const files = readdirSync(dir).filter(f => f.endsWith('.tar.gz')).sort().reverse();
    const latest = files[0];
    const stat = statSync(`${dir}/${latest}`);
    await db.query('INSERT INTO backups (filename, size_kb, status) VALUES ($1,$2,$3)', [latest, Math.round(stat.size/1024), 'ok']);
    res.json({ ok: true, file: latest });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/backup/restore', auth, adminOnly, async (req, res) => {
  try {
    const { file } = req.body;
    execSync(`sudo /home/openclaw/.openclaw/restore.sh ${process.env.BACKUP_DIR}/${file}`);
    await db.query('INSERT INTO agent_logs (agent_id, action, details) VALUES ($1,$2,$3)', ['chiara', 'restore', `Restore de ${file} por ${req.user.name}`]);
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/backup/history', auth, async (req, res) => {
  const result = await db.query('SELECT * FROM backups ORDER BY created_at DESC LIMIT 30');
  res.json({ ok: true, backups: result.rows });
});

// ============================================================
// GATEWAY
// ============================================================
app.post('/api/gateway/restart', auth, adminOnly, async (req, res) => {
  try {
    execSync('sudo systemctl restart openclaw');
    await db.query('INSERT INTO agent_logs (agent_id, action, details) VALUES ($1,$2,$3)', ['chiara', 'gateway_restart', `Gateway reiniciado por ${req.user.name}`]);
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/gateway/status', auth, (req, res) => {
  try {
    const status = execSync('systemctl is-active openclaw').toString().trim();
    res.json({ ok: true, status });
  } catch { res.json({ ok: true, status: 'inactive' }); }
});

// ============================================================
// CONFIG
// ============================================================
app.get('/api/config', auth, (req, res) => {
  try {
    const content = readFileSync(`${process.env.OPENCLAW_DIR}/openclaw.json`, 'utf8');
    res.json({ ok: true, content });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/config', auth, adminOnly, async (req, res) => {
  try {
    const { content } = req.body;
    JSON.parse(content);
    writeFileSync(`${process.env.OPENCLAW_DIR}/openclaw.json`, content, 'utf8');
    execSync('sudo systemctl restart openclaw');
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ============================================================
// GITHUB
// ============================================================
app.post('/api/github/token', auth, async (req, res) => {
  try {
    execSync(`cd ${process.env.OPENCLAW_DIR} && node github-token.mjs`);
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/github/projects', auth, async (req, res) => {
  try {
    const token = readFileSync(`${process.env.OPENCLAW_DIR}/github-token.txt`, 'utf8').trim();
    const octokit = new Octokit({ auth: token });
    const { data } = await octokit.rest.projects.listForOrg({ org: 'sergiomvj', state: 'open' }).catch(() => ({ data: [] }));
    res.json({ ok: true, projects: data });
  } catch(e) { res.json({ ok: true, projects: [] }); }
});

// ============================================================
// PROJECTS & TASKS
// ============================================================
app.get('/api/projects', auth, async (req, res) => {
  const result = await db.query(`
    SELECT p.*, u.name as created_by_name,
      COUNT(DISTINCT t.id) as task_count,
      COUNT(DISTINCT ap.agent_id) as agent_count
    FROM projects p
    LEFT JOIN users u ON p.created_by = u.id
    LEFT JOIN tasks t ON t.project_id = p.id
    LEFT JOIN agent_projects ap ON ap.project_id = p.id
    GROUP BY p.id, u.name ORDER BY p.created_at DESC
  `);
  res.json({ ok: true, projects: result.rows });
});

app.post('/api/projects', auth, async (req, res) => {
  try {
    const { name, description, github_repo, agent_ids } = req.body;
    const result = await db.query(
      'INSERT INTO projects (name, description, github_repo, created_by) VALUES ($1,$2,$3,$4) RETURNING *',
      [name, description, github_repo, req.user.id]
    );
    const project = result.rows[0];
    if (agent_ids?.length) {
      for (const aid of agent_ids) {
        await db.query('INSERT INTO agent_projects (agent_id, project_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [aid, project.id]);
      }
    }
    res.json({ ok: true, project });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/projects/:id/tasks', auth, async (req, res) => {
  const result = await db.query(`
    SELECT t.*, a.name as agent_name, a.color as agent_color
    FROM tasks t LEFT JOIN agents a ON t.agent_id = a.id
    WHERE t.project_id = $1 ORDER BY t.created_at DESC
  `, [req.params.id]);
  res.json({ ok: true, tasks: result.rows });
});

app.post('/api/tasks', auth, async (req, res) => {
  try {
    const { project_id, agent_id, title, description, status, priority, due_date } = req.body;
    const result = await db.query(
      'INSERT INTO tasks (project_id, agent_id, title, description, status, priority, due_date, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
      [project_id, agent_id, title, description, status || 'backlog', priority || 'medium', due_date, req.user.id]
    );
    res.json({ ok: true, task: result.rows[0] });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/tasks/:id', auth, async (req, res) => {
  try {
    const { status, title, description, agent_id, priority } = req.body;
    const result = await db.query(
      `UPDATE tasks SET
        status = COALESCE($1, status),
        title = COALESCE($2, title),
        description = COALESCE($3, description),
        agent_id = COALESCE($4, agent_id),
        priority = COALESCE($5, priority),
        updated_at = NOW()
       WHERE id = $6 RETURNING *`,
      [status, title, description, agent_id, priority, req.params.id]
    );
    res.json({ ok: true, task: result.rows[0] });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ============================================================
// LOGS
// ============================================================
app.get('/api/logs', auth, async (req, res) => {
  const { agent_id, limit } = req.query;
  let query = 'SELECT l.*, a.name as agent_name, a.color as agent_color FROM agent_logs l LEFT JOIN agents a ON l.agent_id = a.id';
  const params = [];
  if (agent_id) { query += ' WHERE l.agent_id = $1'; params.push(agent_id); }
  query += ' ORDER BY l.created_at DESC LIMIT $' + (params.length + 1);
  params.push(parseInt(limit) || 100);
  const result = await db.query(query, params);
  res.json({ ok: true, logs: result.rows });
});

// ============================================================
// START
// ============================================================
const PORT = process.env.PORT || 19010;
app.listen(PORT, '0.0.0.0', () => console.log(`✅ OpenClaw Dashboard API rodando na porta ${PORT}`));
