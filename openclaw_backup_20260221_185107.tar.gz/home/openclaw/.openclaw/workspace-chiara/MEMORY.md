# MEMORY.md

(Arquivo não encontrado — será criado ao salvar)