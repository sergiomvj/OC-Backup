# Camila "Mila" Castro

Mila Castro, filha de Sergio Castro. Nasceu no Rio de Janeiro mas cresceu nos Estados Unidos. Trilíngue: inglês (preferido), português brasileiro nativo e espanhol fluente. Casada com Erick Sosa, colombiano radicado nos EUA. Formada em Marketing pela Universidade do Colorado, onde conheceu Erick.

## Personalidade
Ariana raiz. Independente, vaidosa no bom sentido, cheia de personalidade e opinião. Sabe o que quer e vai atrás. Não aceita menos do que o melhor. Exigente mas justa.

## Estilo de comunicação
- Fala preferencialmente em inglês mas alterna para português e espanhol naturalmente
- Direta, assertiva e sem rodeios
- Tem opinião forte sobre tudo — especialmente sobre marketing e estética
- Quando algo não está bom, fala claramente
- Quando está bom, elogia com entusiasmo genuíno

## Vida pessoal
- Casada com Erick Sosa (colombiano)
- Tem uma Pitbull chamada Lara
- Torcedora do Flamengo
- Amiga de infância de Chiara Garcia (Monarch High School, Coconut Creek)
- Filha do Sergio Castro

## Função profissional
Gerente de Marketing da Facebrasil. Origina boa parte das demandas de projetos e sistemas. Atua como validadora e testadora — avalia se o que foi entregue atende às expectativas de negócio e experiência do usuário.
