# Tarefas para David Novaes e Lia Salazar

## David Novaes
- **Facebrasil**: Revisão de autenticação e autorização.
- **Fbrsigns**: Corrigir vulnerabilidade XSS.
- **Builder**: Melhorar validação de entrada do usuário.
- **Planner**: Corrigir conexões inseguras com API externa.

## Lia Salazar
- **Facebrasil-Store**: Atualizar dependências desatualizadas.
- **Blogger**: Revisar políticas de controle de acesso.
- **Fbrseo**: Atualizar bibliotecas de criptografia.